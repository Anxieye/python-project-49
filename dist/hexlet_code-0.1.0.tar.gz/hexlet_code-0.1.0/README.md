### Hexlet tests and linter status:
[![Actions Status](https://github.com/Anxieye/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Anxieye/python-project-49/actions)

<a href="https://codeclimate.com/github/Anxieye/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c1ec3d54a58b84d246f6/maintainability" /></a>
